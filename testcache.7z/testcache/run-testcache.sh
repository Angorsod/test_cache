java -jar testcache-0.0.1-SNAPSHOT.one-jar.jar
